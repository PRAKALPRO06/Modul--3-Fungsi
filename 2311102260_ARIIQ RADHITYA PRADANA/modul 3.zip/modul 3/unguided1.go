package main

import "fmt"

// Fungsi f(x) = x^2
func f(x int) int {
	return x * x
}

// Fungsi g(x) = x - 2
func g(x int) int {
	return x - 2
}

// Fungsi h(x) = x + 1
func h(x int) int {
	return x + 1
}

// Fungsi untuk menghitung (f o g o h)(x)
func fogoh(x int) int {
	return f(g(h(x)))
}

// Fungsi untuk menghitung (g o h o f)(x)
func gohof(x int) int {
	return g(h(f(x)))
}

// Fungsi untuk menghitung (h o f o g)(x)
func hofog(x int) int {
	return h(f(g(x)))
}

func main() {
	var a, b, c int
	// Masukkan input berupa 3 bilangan bulat
	fmt.Scan(&a, &b, &c)

	// Baris pertama: (f o g o h)(a)
	fogohResult := fogoh(a)
	fmt.Printf("(fogoh)(%d) = %d\n", a, fogohResult)

	// Baris kedua: (g o h o f)(b)
	gohofResult := gohof(b)
	fmt.Printf("(gohof)(%d) = %d\n", b, gohofResult)

	// Baris ketiga: (hofog)(c)
	hofogResult := hofog(c)
	fmt.Printf("(hofog)(%d) = %d\n", c, hofogResult)
}
