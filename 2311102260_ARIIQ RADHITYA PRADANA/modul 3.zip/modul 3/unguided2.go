package main

import (
	"fmt"
	"math"
)

func main() {
	var cx1, cy1, r1 int
	var cx2, cy2, r2 int
	var x, y int

	// Input untuk lingkaran 1
	fmt.Println("Masukkan data lingkaran 1 (format: x y radius):")
	fmt.Scan(&cx1, &cy1, &r1)

	// Input untuk lingkaran 2
	fmt.Println("Masukkan data lingkaran 2 (format: x y radius):")
	fmt.Scan(&cx2, &cy2, &r2)

	// Input untuk titik yang akan diperiksa
	fmt.Println("Masukkan koordinat titik (format: x y):")
	fmt.Scan(&x, &y)

	// Hitung jarak titik ke pusat lingkaran
	d1 := jarak(x, y, cx1, cy1)
	d2 := jarak(x, y, cx2, cy2)

	// Tentukan posisi titik
	if d1 <= float64(r1) && d2 <= float64(r2) {
		fmt.Printf("titik di bawah lingkaran 1 dan 2\n")
	} else if d1 <= float64(r1) {
		fmt.Printf("titik di bawah lingkaran 1\n")
	} else if d2 <= float64(r2) {
		fmt.Printf("titik di bawah lingkaran 2\n")
	} else {
		fmt.Printf("titik di luar lingkaran 1 dan 2\n")
	}
}

// Fungsi untuk menghitung jarak antara dua titik
func jarak(a, b, c, d int) float64 {
	return math.Sqrt(math.Pow(float64(a-c), 2) + math.Pow(float64(b-d), 2))
}
